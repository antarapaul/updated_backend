package com.capg.search.service;

import java.util.List;

import com.capg.search.model.Groups;
import com.capg.search.model.UserProfile;

public interface ISearchService {
	
	public List<String> getGroupNames(String letter);

	public List<String> getUserName(String username);

	public List<Groups> getAllGroupNames();

	public List<UserProfile> getAllUserNames();

}
