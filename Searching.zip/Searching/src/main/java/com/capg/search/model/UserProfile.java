package com.capg.search.model;



import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;


@Entity  
public class UserProfile {
	
		@Id
		@GeneratedValue
		private Integer userId;
		private String userName;
		public UserProfile() {
			super();
		}
		
		public UserProfile(Integer userId, String userName) {
			super();
			this.userId = userId;
			this.userName = userName;
		}

		public Integer getUserId() {
			return userId;
		}

		public void setUserId(Integer userId) {
			this.userId = userId;
		}

		public String getUserName() {
			return userName;
		}

		public void setUserName(String userName) {
			this.userName = userName;
		}

		@Override
		public String toString() {
			return "UserProfile [userId=" + userId + ", userName=" + userName + "]";
		}
		
		
		
		
		
/*		@OneToOne
		@JoinColumn(name="Addressfk")
		private Address address;
		private Boolean isPrivateDob;
		private Date dob;
		private Boolean isPrivateAreaofIntrest;
		private String areaofInterest;
		@OneToMany(mappedBy="user",targetEntity=Albums.class,cascade=CascadeType.ALL,fetch=FetchType.LAZY)
		private List<Albums> albums=new ArrayList<Albums>();
		private Boolean isPrivategender;
		private String gender;
		private Long mobileNo;
		private Boolean isPrivateMobileNo;
		@ManyToMany
		@JoinTable(name="user_status",joinColumns= {@JoinColumn(name="user")},inverseJoinColumns= {@JoinColumn(name="groups")})
		private List<Groups> groups;
		
		@OneToMany(mappedBy="user",targetEntity=Status.class,cascade=CascadeType.ALL,fetch=FetchType.LAZY)
		private List<Status> status;
		
		@OneToMany(mappedBy="user",targetEntity=Chat.class,cascade=CascadeType.ALL,fetch=FetchType.LAZY)
		private List<Chat> chat;
		
//		@OneToOne
//		@JoinColumn(name="email" ,mappedBy="")
		private String email;
		private Boolean isPrivateEmail;*/
		 
	 

	

}
