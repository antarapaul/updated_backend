package com.capg.search.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;

import org.springframework.stereotype.Service;


import com.capg.search.dao.ISearchDao;
import com.capg.search.dao.IUserSearchDao;
import com.capg.search.model.Groups;
import com.capg.search.model.UserProfile;

@Service("searchService")
public class SearchServiceImpl implements ISearchService{
	
	@Autowired
	private ISearchDao searchDao;
	
	@Autowired
	private IUserSearchDao userSearchDao;

	@Override
	public List<String> getGroupNames(String letter) {
		return searchDao.getGroupNames(letter);
	}

	@Override
	public List<String> getUserName(String username) {
		
		return userSearchDao.getUserName(username);
	}

	@Override
	public List<Groups> getAllGroupNames() {
		
		return searchDao.findAll();
	}

	@Override
	public List<UserProfile> getAllUserNames() {
		
		return userSearchDao.findAll();
	}

}
