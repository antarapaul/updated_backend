package com.capg.search.dao;

import java.util.List;

import javax.transaction.Transactional;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import com.capg.search.model.UserProfile;

@Transactional
@Repository("userSearchDao")
public interface IUserSearchDao extends JpaRepository<UserProfile,Integer>{
	
	@Query("select u.userName from UserProfile u where u.userName like :username%")
	List<String> getUserName(@Param("username") String username);
	
	

}
